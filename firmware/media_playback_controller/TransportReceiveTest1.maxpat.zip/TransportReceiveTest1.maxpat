{
    "patcher": {
        "fileversion": 1,
        "appversion": {
            "major": 9,
            "minor": 1,
            "revision": 4,
            "architecture": "x64",
            "modernui": 1
        },
        "classnamespace": "box",
        "openrect": [ 300.0, 300.0, 600.0, 200.0 ],
        "openrectmode": 0,
        "openinpresentation": 1,
        "toolbarvisible": 0,
        "boxes": [
            {
                "box": {
                    "id": "obj-33",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 350.0, 225.0, 150.0, 20.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 225.0, 172.0, 150.0, 20.0 ],
                    "text": "Transport Receive Test 1",
                    "textjustification": 1
                }
            },
            {
                "box": {
                    "bgcolor": [ 0.125, 0.125, 0.125, 0.0 ],
                    "blinkcolor": [ 0.999995052814484, 1.0, 1.0, 0.8 ],
                    "id": "obj-30",
                    "maxclass": "button",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "bang" ],
                    "outlinecolor": [ 0.999995052814484, 1.0, 1.0, 0.5 ],
                    "parameter_enable": 0,
                    "patching_rect": [ 118.0, 79.0, 24.0, 24.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 23.0, 54.0, 64.0, 64.0 ]
                }
            },
            {
                "box": {
                    "id": "obj-17",
                    "linecount": 9,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 967.0, 473.0, 294.0, 141.0 ],
                    "presentation": 1,
                    "presentation_linecount": 9,
                    "presentation_rect": [ 347.0, 22.0, 245.0, 141.0 ],
                    "text": "/transport/play 1 (integer)\n/transport/pause 1 (integer)\n/transport/stop 1 (integer)\n/volume <float 0.0–1.0> — e.g. /volume 0.65\nnaodec-playback.local\n9000\n192.168.50.2\n192.168.50.114\n\n"
                }
            },
            {
                "box": {
                    "floatoutput": 1,
                    "id": "obj-13",
                    "maxclass": "slider",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 154.0, 108.0, 115.0, 20.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 89.0, 125.0, 212.0, 30.0 ],
                    "size": 1.0
                }
            },
            {
                "box": {
                    "bgcolor": [ 0.125, 0.125, 0.125, 0.0 ],
                    "blinkcolor": [ 0.999995052814484, 1.0, 1.0, 0.8 ],
                    "id": "obj-10",
                    "maxclass": "button",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "bang" ],
                    "outlinecolor": [ 0.999995052814484, 1.0, 1.0, 0.5 ],
                    "parameter_enable": 0,
                    "patching_rect": [ 50.0, 176.0, 24.0, 24.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 89.0, 54.0, 64.0, 64.0 ]
                }
            },
            {
                "box": {
                    "bgcolor": [ 0.125, 0.125, 0.125, 0.0 ],
                    "blinkcolor": [ 0.999995052814484, 1.0, 1.0, 0.8 ],
                    "id": "obj-9",
                    "maxclass": "button",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "bang" ],
                    "outlinecolor": [ 0.999995052814484, 1.0, 1.0, 0.5 ],
                    "parameter_enable": 0,
                    "patching_rect": [ 208.0, 176.0, 24.0, 24.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 163.0, 54.0, 64.0, 64.0 ]
                }
            },
            {
                "box": {
                    "bgcolor": [ 0.125, 0.125, 0.125, 0.0 ],
                    "blinkcolor": [ 0.999995052814484, 1.0, 1.0, 0.8 ],
                    "id": "obj-7",
                    "maxclass": "button",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "bang" ],
                    "outlinecolor": [ 0.999995052814484, 1.0, 1.0, 0.5 ],
                    "parameter_enable": 0,
                    "patching_rect": [ 377.0, 176.0, 24.0, 24.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 237.0, 54.0, 64.0, 64.0 ]
                }
            },
            {
                "box": {
                    "color": [ 0.059471659362316, 0.501942574977875, 0.998464584350586, 1.0 ],
                    "id": "obj-11",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [ "", "" ],
                    "patching_rect": [ 154.0, 80.0, 115.0, 22.0 ],
                    "text": "OSC-route /volume/"
                }
            },
            {
                "box": {
                    "color": [ 0.059471659362316, 0.501942574977875, 0.998464584350586, 1.0 ],
                    "id": "obj-12",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [ "", "" ],
                    "patching_rect": [ 377.0, 152.0, 151.0, 22.0 ],
                    "text": "OSC-route /transport/stop/"
                }
            },
            {
                "box": {
                    "color": [ 0.059471659362316, 0.501942574977875, 0.998464584350586, 1.0 ],
                    "id": "obj-8",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [ "", "" ],
                    "patching_rect": [ 208.0, 152.0, 159.0, 22.0 ],
                    "text": "OSC-route /transport/pause/"
                }
            },
            {
                "box": {
                    "color": [ 0.059471659362316, 0.501942574977875, 0.998464584350586, 1.0 ],
                    "id": "obj-5",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [ "", "" ],
                    "patching_rect": [ 50.0, 152.0, 149.0, 22.0 ],
                    "text": "OSC-route /transport/play/"
                }
            },
            {
                "box": {
                    "id": "obj-3",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 50.0, 43.0, 219.0, 22.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 86.0, 22.0, 219.0, 22.0 ],
                    "text": "udpreceive naodec-playback.local 9000"
                }
            },
            {
                "box": {
                    "bgcolor": [ 0.066666666666667, 0.501960784313725, 0.250980392156863, 1.0 ],
                    "fontsize": 14.0,
                    "id": "obj-851",
                    "maxclass": "textbutton",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "", "", "int" ],
                    "parameter_enable": 0,
                    "parameter_mappable": 0,
                    "patching_rect": [ 50.0, 202.0, 64.0, 64.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 89.0, 54.0, 64.0, 64.0 ],
                    "rounded": 8.0,
                    "text": "Play",
                    "textcolor": [ 0.905882, 0.909804, 0.917647, 1.0 ],
                    "texton": "Play",
                    "textoncolor": [ 0.999995052814484, 1.0, 1.0, 1.0 ]
                }
            },
            {
                "box": {
                    "bgcolor": [ 0.843137254901961, 0.674509803921569, 0.337254901960784, 1.0 ],
                    "bgoncolor": [ 1.0, 0.709803921568627, 0.196078431372549, 1.0 ],
                    "fontsize": 14.0,
                    "id": "obj-201",
                    "maxclass": "textbutton",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "", "", "int" ],
                    "parameter_enable": 0,
                    "parameter_mappable": 0,
                    "patching_rect": [ 208.0, 202.0, 64.0, 64.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 163.0, 54.0, 64.0, 64.0 ],
                    "rounded": 8.0,
                    "text": "Pause",
                    "textcolor": [ 0.905882, 0.909804, 0.917647, 1.0 ],
                    "texton": "Pause",
                    "textoncolor": [ 0.999995052814484, 1.0, 1.0, 1.0 ],
                    "usebgoncolor": 1
                }
            },
            {
                "box": {
                    "bgcolor": [ 0.501962602138519, 0.0, 0.008127611130476, 1.0 ],
                    "fontsize": 14.0,
                    "id": "obj-850",
                    "maxclass": "textbutton",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "", "", "int" ],
                    "parameter_enable": 0,
                    "parameter_mappable": 0,
                    "patching_rect": [ 377.0, 202.0, 64.0, 64.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 237.0, 54.0, 64.0, 64.0 ],
                    "rounded": 8.0,
                    "text": "Stop",
                    "textcolor": [ 0.905882, 0.909804, 0.917647, 1.0 ],
                    "texton": "Stop",
                    "textoncolor": [ 0.999995052814484, 1.0, 1.0, 1.0 ]
                }
            },
            {
                "box": {
                    "angle": 270.0,
                    "background": 1,
                    "bgcolor": [ 0.0, 0.0, 0.0, 1.0 ],
                    "border": 1,
                    "bordercolor": [ 0.9999960065, 1.0, 1.0, 1.0 ],
                    "id": "obj-31",
                    "maxclass": "panel",
                    "mode": 0,
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 619.0, 94.0, 128.0, 128.0 ],
                    "presentation": 1,
                    "presentation_rect": [ 0.0, 0.0, 600.0, 200.0 ],
                    "proportion": 0.5,
                    "rounded": 20
                }
            }
        ],
        "lines": [
            {
                "patchline": {
                    "destination": [ "obj-851", 0 ],
                    "source": [ "obj-10", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-13", 0 ],
                    "source": [ "obj-11", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-7", 0 ],
                    "source": [ "obj-12", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-11", 0 ],
                    "midpoints": [ 59.5, 73.94921875, 163.5, 73.94921875 ],
                    "order": 2,
                    "source": [ "obj-3", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-12", 0 ],
                    "midpoints": [ 59.5, 139.0625, 386.5, 139.0625 ],
                    "order": 0,
                    "source": [ "obj-3", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-30", 0 ],
                    "order": 3,
                    "source": [ "obj-3", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-5", 0 ],
                    "order": 4,
                    "source": [ "obj-3", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-8", 0 ],
                    "midpoints": [ 59.5, 146.18359375, 217.5, 146.18359375 ],
                    "order": 1,
                    "source": [ "obj-3", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-10", 0 ],
                    "source": [ "obj-5", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-850", 0 ],
                    "source": [ "obj-7", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-9", 0 ],
                    "source": [ "obj-8", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "obj-201", 0 ],
                    "source": [ "obj-9", 0 ]
                }
            }
        ],
        "autosave": 0
    }
}